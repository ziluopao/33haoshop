<?php
defined('In33hao') or exit('Access Invalid!');
/**
 * index
 */
$lang['express_name']	= '快遞公司';
$lang['express_order']	= '常用';
$lang['express_state']	= '狀態';
$lang['express_letter']	= '首字母';
$lang['express_url']	= '網址 (僅供參考)';

$lang['express_index_help1']		= '系統內置的快遞公司不得刪除，只可編輯狀態，平台可禁用不需要的快遞公司，預設按首字母進行排序，常用的快遞公司將會排在靠前位置';
$lang['express_index_help2']		= '更改狀態後，需要到 設置 -> 清理緩存 中，清理快遞公司緩存 後，才會生效';