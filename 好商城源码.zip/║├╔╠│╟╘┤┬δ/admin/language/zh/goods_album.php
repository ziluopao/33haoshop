<?php
defined('In33hao') or exit('Access Invalid!');
/**
 * 圖片空間
 */
$lang['g_album_manage']			= '圖片空間';
$lang['g_album_list']			= '相冊列表';
$lang['g_album_pic_list']		= '圖片列表';
$lang['g_album_keyword']		= '請輸入店舖ID或完整名稱';
$lang['g_album_del_tips']		= '相冊刪除後，相冊內全部圖片都會刪除，不能恢復，請謹慎操作';
$lang['g_album_fmian']			= '封面';
$lang['g_album_one']			= '相冊';
$lang['g_album_shop']			= '店舖';
$lang['g_album_pic_count']		= '圖片數';
$lang['g_album_pic_one']		= '圖片';
$lang['g_album_manage']			= '圖片空間';
$lang['g_album_manage']			= '圖片空間';