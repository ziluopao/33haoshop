<?php
defined('In33hao') or exit('Access Invalid!');

$lang['admin_log_man']			= '操作人';
$lang['admin_log_do']			= '行为';
$lang['admin_log_dotime']		= '时间';
$lang['admin_log_ago_1zhou']	= '一周前';
$lang['admin_log_ago_1month']	= '一个月前';
$lang['admin_log_ago_2month']	= '两个月前';
$lang['admin_log_ago_3month']	= '三个月前';
$lang['admin_log_ago_6month']	= '六个月前';
$lang['admin_log_tips1']		= '系统默认关闭了操作日志，如需开启，请编辑admin/config/config.ini.php: $config[\'sys_log\'] = true;';
$lang['admin_log_tips2']		= '开启操作日志可以记录管理人员的关键操作，但会轻微加重系统负担';

