<?php
defined('In33hao') or exit('Access Invalid!');

$lang['admin_snsstrace_storename']	= '店铺名称';
$lang['store_sns_coupon_price']		= '优惠券面额';
$lang['store_sns_start-stop_time']	= '	起止时间';
$lang['store_sns_formerprice']		= '促销价格';
$lang['store_sns_bundling_price']	= '套餐价格';
$lang['store_sns_free_shipping']	= '免运费';
$lang['store_sns_goodsprice']		= '商品原价';
$lang['store_sns_groupprice']		= '抢购价格';
$lang['sns_sharegoods_price']		= '价&nbsp;&nbsp;格';
$lang['sns_sharegoods_freight']		= '运&nbsp;&nbsp;费';
$lang['store_sns_trace_type']		= '动态类型';
$lang['store_sns_normal']			= '新鲜事';
$lang['store_sns_new']				= '新品';
$lang['store_sns_coupon']			= '优惠券';
$lang['store_sns_xianshi']			= '限时折扣';
$lang['store_sns_mansong']			= '满即送';
$lang['store_sns_bundling']			= '优惠套装';
$lang['store_sns_groupbuy']			= '抢购';
$lang['store_sns_recommend']		= '推荐';
$lang['store_sns_hotsell']			= '热销';

$lang['store_sns_new_selease']		= '新品发布';
$lang['store_sns_coupon']			= '优惠券';
$lang['store_sns_xianshi']			= '限时折扣';
$lang['store_sns_mansong']			= '满即送';
$lang['store_sns_bundling']			= '优惠套装';
$lang['store_sns_gronpbuy']			= '抢购';
$lang['store_sns_store_recommend']	= '店铺推荐';
$lang['store_sns_hotsell']			= '热销商品';