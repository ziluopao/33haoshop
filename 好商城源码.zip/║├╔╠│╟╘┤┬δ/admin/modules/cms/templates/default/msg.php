<?php defined('In33hao') or exit('Access Invalid!');?>
<?php echo $output['msg']; ?>