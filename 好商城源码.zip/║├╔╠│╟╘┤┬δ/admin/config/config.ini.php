<?php
defined('In33hao') or exit('Access Invalid!');

$config['sys_log']          = true;

return $config;
